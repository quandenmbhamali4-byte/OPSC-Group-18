package com.example.coinquest

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.coinquest.databinding.ActivityExpensesBinding
import com.example.coinquest.utils.Logger
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*


class ExpensesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityExpensesBinding
    private lateinit var transactionAdapter: TransactionAdapter
    private val transactions = mutableListOf<Transactions>()
    private val filteredTransactions = mutableListOf<Transactions>()
    private var nextId = 6
    private var selectedFilterCategory = "All"
    private var selectedFilterDate = "All"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExpensesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
        loadTransactions()
        updateTotals()

        Logger.d("ExpensesActivity", "Expenses screen loaded")
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Expenses"
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        transactionAdapter = TransactionAdapter(
            transactions = filteredTransactions,
            onDeleteClick = { transaction, position -> deleteTransaction(transactions, position) },
            onEditClick = { transaction, position -> showEditDialog(transactions, position) }
        )
        binding.rvExpenses.layoutManager = LinearLayoutManager(this)
        binding.rvExpenses.adapter = transactionAdapter
    }

    private fun setupClickListeners() {
        binding.fabAddExpense.setOnClickListener {
            showAddExpenseDialog()
        }

        binding.btnFilterCategory.setOnClickListener {
            showCategoryFilterDialog()
        }

        binding.btnFilterDate.setOnClickListener {
            showDateFilterDialog()
        }

        binding.btnClearFilters.setOnClickListener {
            clearFilters()
        }

        binding.btnExport.setOnClickListener {
            exportExpenses()
        }

        binding.spinnerSort.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val sortBy = parent.getItemAtPosition(position).toString()
                sortTransactions(sortBy)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        })
    }

    private fun loadTransactions() {
        // Sample data matching the original image
        transactions.clear()
        transactions.addAll(
            listOf(
                Transactions(0, "GroceryStore", 45.20, "Grocery", "Apr21"),
                Transactions(1, "Movie Tickets", 30.00, "Entertainment", "Apr19"),
                Transactions(2, "NewSheor", 65.00, "Food", "Apr12"),
                Transactions(3, "GasStation", 37.00, "Bills", "Apr7"),
                Transactions(4, "DinnerDate", 120.00, "Food", "Apr3"),
                Transactions(5, "MiyDedl", 45.40, "Food", "Apr3"),
                Transactions(6, "Coffee Shop", 8.50, "Food", "Apr22"),
                Transactions(7, "Amazon Shopping", 89.99, "Shopping", "Apr20"),
                Transactions(8, "Netflix", 15.99, "Entertainment", "Apr15"),
                Transactions(9, "Electric Bill", 85.00, "Bills", "Apr10")
            )
        )
        nextId = 10
        applyFilters()
    }

    private fun applyFilters() {
        filteredTransactions.clear()

        var filtered = transactions.toList()

        // Apply category filter
        if (selectedFilterCategory != "All") {
            filtered = filtered.filter { it.category == selectedFilterCategory }
        }

        // Apply date filter
        if (selectedFilterDate != "All") {
            filtered = filtered.filter { it.date.contains(selectedFilterDate) }
        }

        filteredTransactions.addAll(filtered)
        transactionAdapter.updateData(filteredTransactions)
        updateTotals()

        // Update filter button text
        binding.btnFilterCategory.text = if (selectedFilterCategory == "All") "Category" else selectedFilterCategory
        binding.btnFilterDate.text = if (selectedFilterDate == "All") "Date" else selectedFilterDate
        binding.tvFilterCount.text = "${filteredTransactions.size} items"
    }

    private fun clearFilters() {
        selectedFilterCategory = "All"
        selectedFilterDate = "All"
        applyFilters()
        Toast.makeText(this, "Filters cleared", Toast.LENGTH_SHORT).show()
    }

    private fun showCategoryFilterDialog() {
        val categories = arrayOf("All", "Food", "Grocery", "Entertainment", "Bills", "Shopping")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Filter by Category")
            .setItems(categories) { _, which ->
                selectedFilterCategory = categories[which]
                applyFilters()
            }
            .show()
    }

    private fun showDateFilterDialog() {
        val dates = arrayOf("All", "Apr21", "Apr20", "Apr19", "Apr15", "Apr12", "Apr10", "Apr7", "Apr3")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Filter by Date")
            .setItems(dates) { _, which ->
                selectedFilterDate = dates[which]
                applyFilters()
            }
            .show()
    }

    private fun sortTransactions(sortBy: String) {
        when (sortBy) {
            "Date (Newest)" -> filteredTransactions.sortByDescending { it.date }
            "Date (Oldest)" -> filteredTransactions.sortBy { it.date }
            "Amount (Highest)" -> filteredTransactions.sortByDescending { it.amount }
            "Amount (Lowest)" -> filteredTransactions.sortBy { it.amount }
            "Name (A-Z)" -> filteredTransactions.sortBy { it.name }
            "Name (Z-A)" -> filteredTransactions.sortByDescending { it.name }
        }
        transactionAdapter.updateData(filteredTransactions)
        Toast.makeText(this, "Sorted by: $sortBy", Toast.LENGTH_SHORT).show()
    }

    private fun updateTotals() {
        val total = filteredTransactions.sumOf { it.amount }
        val average = if (filteredTransactions.isNotEmpty()) total / filteredTransactions.size else 0.0

        binding.tvTotalExpenses.text = String.format("$%.2f", total)
        binding.tvAverageExpense.text = String.format("$%.2f", average)
        binding.tvTransactionCount.text = "${filteredTransactions.size} transactions"
    }

    private fun showAddExpenseDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_expense, null)
        val etName = dialogView.findViewById<EditText>(R.id.etExpenseName)
        val etAmount = dialogView.findViewById<EditText>(R.id.etExpenseAmount)
        val spinnerCategory = dialogView.findViewById<Spinner>(R.id.spinnerExpenseCategory)
        val etDate = dialogView.findViewById<EditText>(R.id.ExpenseDate)
        val btnDatePicker = dialogView.findViewById<Button>(R.id.btnDatePicker)

        // Setup category spinner
        val categories = arrayOf("Food", "Grocery", "Entertainment", "Bills", "Shopping")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategory.adapter = adapter

        // Date picker
        val calendar = Calendar.getInstance()
        val dateFormat = SimpleDateFormat("MMMdd", Locale.US)

        btnDatePicker.setOnClickListener {
            DatePickerDialog(this, { _, year, month, day ->
                calendar.set(year, month, day)
                val formattedDate = dateFormat.format(calendar.time)
                etDate.setText(formattedDate)
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Add Expense")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val name = etName.text.toString()
                val amount = etAmount.text.toString().toDoubleOrNull()
                val category = spinnerCategory.selectedItem.toString()
                val date = etDate.text.toString()

                if (validateInput(name, amount, date)) {
                    addTransaction(Transactions(nextId++, name, amount!!, category, date))
                } else {
                    Toast.makeText(this, "Please fill all fields correctly", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    private fun showEditDialog(transaction: Transactions, position: Int) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_expense, null)
        val etName = dialogView.findViewById<EditText>(R.id.etExpenseName)
        val etAmount = dialogView.findViewById<EditText>(R.id.etExpenseAmount)
        val spinnerCategory = dialogView.findViewById<Spinner>(R.id.spinnerExpenseCategory)
        val etDate = dialogView.findViewById<EditText>(R.id.etExpenseDate)
        val btnDatePicker = dialogView.findViewById<Button>(R.id.btnDatePicker)

        // Pre-fill data
        etName.setText(transaction.name)
        etAmount.setText(transaction.amount.toString())
        etDate.setText(transaction.date)

        val categories = arrayOf("Food", "Grocery", "Entertainment", "Bills", "Shopping")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategory.adapter = adapter

        val categoryIndex = categories.indexOfFirst { it == transaction.category }
        if (categoryIndex >= 0) spinnerCategory.setSelection(categoryIndex)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Edit Expense")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text.toString()
                val amount = etAmount.text.toString().toDoubleOrNull()
                val category = spinnerCategory.selectedItem.toString()
                val date = etDate.text.toString()

                if (validateInput(name, amount, date)) {
                    updateTransaction(transaction.copy(name = name, amount = amount!!, category = category, date = date), position)
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    private fun validateInput(name: String, amount: Double?, date: String): Boolean {
        return name.isNotEmpty() && amount != null && amount > 0 && date.isNotEmpty()
    }

    private fun addTransaction(transaction: Transactions) {
        transactions.add(transaction)
        applyFilters()
        updateTotals()
        Toast.makeText(this, "Expense added", Toast.LENGTH_SHORT).show()
        Logger.d("Expenses", "Added: ${transaction.name}")
    }

    private fun updateTransaction(transaction: Transactions, position: Int) {
        val index = transactions.indexOfFirst { it.id == transaction.id }
        if (index >= 0) {
            transactions[index] = transaction
            applyFilters()
            updateTotals()
            Toast.makeText(this, "Expense updated", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteTransaction(transaction: Transactions, position: Int) {
        AlertDialog.Builder(this)
            .setTitle("Delete Expense")
            .setMessage("Are you sure you want to delete ${transaction.name}?")
            .setPositiveButton("Delete") { _, _ ->
                transactions.removeAll { it.id == transaction.id }
                applyFilters()
                updateTotals()
                Toast.makeText(this, "Expense deleted", Toast.LENGTH_SHORT).show()
                Logger.d("Expenses", "Deleted: ${transaction.name}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun exportExpenses() {
        lifecycleScope.launch {
            Toast.makeText(this@ExpensesActivity, "Exporting expenses...", Toast.LENGTH_SHORT).show()
            delay(1000)
            Toast.makeText(this@ExpensesActivity, "Exported ${filteredTransactions.size} transactions", Toast.LENGTH_LONG).show()
            Logger.d("Expenses", "Exported ${filteredTransactions.size} transactions")
        }
    }
}