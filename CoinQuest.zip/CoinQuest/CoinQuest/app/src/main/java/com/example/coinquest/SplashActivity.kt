package com.example.coinquest

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.google.android.material.progressindicator.LinearProgressIndicator

class SplashActivity : AppCompatActivity() {

    private lateinit var appLogo: ImageView
    private lateinit var appTitle: TextView
    private lateinit var progressIndicator: LinearProgressIndicator

    private val handler = Handler(Looper.getMainLooper())
    private var runnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        // Enables modern splash screen (Android 12+)
        installSplashScreen()

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        initializeViews()
        applyEnterAnimation()
        preloadData()
        scheduleNavigation()
    }

    private fun initializeViews() {
        appLogo = findViewById(R.id.appLogo)
        appTitle = findViewById(R.id.appTitle)
        progressIndicator = findViewById(R.id.progressIndicator)
    }

    private fun applyEnterAnimation() {
        val fadeIn = AnimationUtils.loadAnimation(this, android.R.anim.fade_in)
        val slideUp = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left)

        appLogo.startAnimation(slideUp)
        appTitle.startAnimation(fadeIn)

        appLogo.visibility = View.VISIBLE
        appTitle.visibility = View.VISIBLE
    }

    private fun preloadData() {
        // Simulate data preloading with progress
        simulateProgressLoading()
    }

    private fun simulateProgressLoading() {
        progressIndicator.visibility = View.VISIBLE

        // Animate progress from 0 to 100 over the splash duration
        progressIndicator.apply {
            progress = 0
            animate()
                .setDuration(SPLASH_DURATION)
                .setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        progress = 100
                    }
                })
        }

        // Gradually increase progress
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (progressIndicator.progress < 100) {
                    progressIndicator.progress += 5
                    handler.postDelayed(this, SPLASH_DURATION / 20)
                }
            }
        }, SPLASH_DURATION / 20)
    }

    private fun scheduleNavigation() {
        runnable = Runnable {
            navigateWithAnimation()
        }

        handler.postDelayed(runnable!!, SPLASH_DURATION)
    }

    private fun navigateWithAnimation() {
        val exitAnimation = AnimationUtils.loadAnimation(this, android.R.anim.fade_out)

        findViewById<View>(android.R.id.content).startAnimation(exitAnimation)

        // Wait for exit animation to complete before navigating
        exitAnimation.setAnimationListener(object : android.view.animation.Animation.AnimationListener {
            override fun onAnimationStart(animation: android.view.animation.Animation?) {}

            override fun onAnimationEnd(animation: android.view.animation.Animation?) {
                navigateToMain()
            }

            override fun onAnimationRepeat(animation: android.view.animation.Animation?) {}
        })
    }

    private fun navigateToMain() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)

        // Add custom transition
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        // Clean up to prevent memory leaks
        runnable?.let { handler.removeCallbacks(it) }
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        private const val SPLASH_DURATION = 2500L // 2.5 seconds
    }
}