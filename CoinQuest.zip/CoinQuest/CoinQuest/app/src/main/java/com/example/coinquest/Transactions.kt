package com.example.coinquest

data class Transactions(
    val id: Int,
    val name: String,
    val amount: Double,
    val category: String,
    val date: String
)