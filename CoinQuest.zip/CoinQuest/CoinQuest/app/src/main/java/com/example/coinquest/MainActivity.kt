package com.example.coinquest

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.coinquest.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var transactionAdapter: TransactionAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupDateRange()
        setupRecyclerView()
        calculateTotalSpent()
    }

    private fun setupDateRange() {
        val dateFormat = SimpleDateFormat("MMM dd", Locale.getDefault())
        val startDate = Calendar.getInstance().apply { set(2026, Calendar.APRIL, 1) }
        val endDate = Calendar.getInstance().apply { set(2026, Calendar.APRIL, 21) }

        val dateRangeText = "${dateFormat.format(startDate.time)} – ${dateFormat.format(endDate.time)}"
        binding.tvDateRange.text = dateRangeText
    }

    private fun setupRecyclerView() {
        // Sample transaction data
        val transactions = listOf(
            Transactions("Coffee Shop", "Food & Drink", 4.50, "2026-04-20", "☕"),
            Transactions("Grocery Store", "Groceries", 85.30, "2026-04-19", "🛒"),
            Transactions("Uber Ride", "Transport", 12.75, "2026-04-18", "🚗"),
            Transactions("Netflix", "Entertainment", 15.99, "2026-04-17", "🎬"),
            Transactions("Gas Station", "Fuel", 45.00, "2026-04-16", "⛽"),
            Transactions("Restaurant", "Dining", 62.40, "2026-04-15", "🍽️"),
            Transactions("Pharmacy", "Health", 23.10, "2026-04-14", "💊")
        )

        transactionAdapter = TransactionAdapter(transactions)
        binding.rvTransactions.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = transactionAdapter
        }
    }

    private fun calculateTotalSpent() {
        val total = transactionAdapter.transactions.sumOf { it.amount }
        binding.tvTotalAmount.text = String.format("$%.2f", total)
    }
}

// Data class for a transaction
data class Transaction(
    val merchantName: String,
    val category: String,
    val amount: Double,
    val date: String,
    val icon: String
)