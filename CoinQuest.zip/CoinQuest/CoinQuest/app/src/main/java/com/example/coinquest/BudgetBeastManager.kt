package com.example.coinquest

class BudgetBeastManager {

    fun getMood(totalSpent: Double, maxBudget: Double): Int {
        return when {
            totalSpent < maxBudget * 0.7 -> 0 // happy
            totalSpent <= maxBudget -> 1 // neutral
            else -> 2 // sad
        }
    }
}

