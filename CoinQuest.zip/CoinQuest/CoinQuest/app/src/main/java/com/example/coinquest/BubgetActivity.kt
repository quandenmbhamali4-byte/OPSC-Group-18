package com.example.coinquest

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.coinquest.databinding.ActivityBudgetBinding
import com.example.coinquest.utils.Logger
import java.util.*

data class BudgetCategory(
    val id: Int,
    val name: String,
    val budgetAmount: Double,
    val spentAmount: Double,
    val color: Int
)

class BudgetActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBudgetBinding
    private lateinit var budgetAdapter: BudgetCategoryAdapter
    private val budgetCategories = mutableListOf<BudgetCategory>()
    private var totalBudget = 1500.00
    private var currentMonth = "April"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBudgetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
        loadBudgetData()
        updateBudgetSummary()

        Logger.d("BudgetActivity", "Budget screen loaded")
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Budget"
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        budgetAdapter = BudgetCategoryAdapter(budgetCategories) { category ->
            showEditBudgetDialog(category)
        }
        binding.rvBudgetCategories.layoutManager = LinearLayoutManager(this)
        binding.rvBudgetCategories.adapter = budgetAdapter
    }

    private fun setupClickListeners() {
        binding.fabAddBudget.setOnClickListener {
            showAddBudgetDialog()
        }

        binding.btnEditTotalBudget.setOnClickListener {
            showEditTotalBudgetDialog()
        }

        binding.btnPreviousMonth.setOnClickListener {
            changeMonth(-1)
        }

        binding.btnNextMonth.setOnClickListener {
            changeMonth(1)
        }
    }

    private fun loadBudgetData() {
        // Sample budget data with actual expenses
        budgetCategories.clear()
        budgetCategories.addAll(
            listOf(
                BudgetCategory(1, "Food", 500.00, 230.40, R.color.food_bg),
                BudgetCategory(2, "Grocery", 400.00, 45.20, R.color.grocery_bg),
                BudgetCategory(3, "Entertainment", 200.00, 45.99, R.color.entertainment_bg),
                BudgetCategory(4, "Bills", 300.00, 122.00, R.color.bills_bg),
                BudgetCategory(5, "Shopping", 100.00, 89.99, R.color.shopping_bg)
            )
        )

        val totalSpent = budgetCategories.sumOf { it.spentAmount }
        binding.progressTotalBudget.progress = ((totalSpent / totalBudget) * 100).toInt()
        binding.tvRemainingBudget.text = String.format("$%.2f remaining", totalBudget - totalSpent)

        budgetAdapter.updateData(budgetCategories)
    }

    private fun updateBudgetSummary() {
        val totalSpent = budgetCategories.sumOf { it.spentAmount }
        val remainingBudget = totalBudget - totalSpent
        val percentageUsed = (totalSpent / totalBudget) * 100

        binding.tvTotalBudgetAmount.text = String.format("$%.2f", totalBudget)
        binding.tvSpentAmount.text = String.format("$%.2f", totalSpent)
        binding.tvRemainingAmount.text = String.format("$%.2f", remainingBudget)
        binding.progressTotalBudget.progress = percentageUsed.toInt()

        // Update progress bar color based on usage
        val color = when {
            percentageUsed < 50 -> R.color.grocery_text
            percentageUsed < 80 -> R.color.entertainment_text
            else -> R.color.delete_text
        }
        binding.progressTotalBudget.progressTintList = ContextCompat.getColorStateList(this, color)

        // Alert if budget exceeded
        if (remainingBudget < 0) {
            binding.tvWarning.visibility = View.VISIBLE
            binding.tvWarning.text = "⚠️ Budget exceeded by ${String.format("$%.2f", -remainingBudget)}"
        } else if (percentageUsed > 90) {
            binding.tvWarning.visibility = View.VISIBLE
            binding.tvWarning.text = "⚠️ Warning: You've used ${String.format("%.0f", percentageUsed)}% of your budget"
        } else {
            binding.tvWarning.visibility = View.GONE
        }
    }

    private fun changeMonth(delta: Int) {
        val months = arrayOf("January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December")
        val currentIndex = months.indexOf(currentMonth)
        var newIndex = currentIndex + delta

        if (newIndex < 0) newIndex = 11
        if (newIndex > 11) newIndex = 0

        currentMonth = months[newIndex]
        binding.tvCurrentMonth.text = currentMonth

        // Reload data for new month
        loadBudgetData()
        Toast.makeText(this, "Showing budget for $currentMonth", Toast.LENGTH_SHORT).show()
    }

    private fun showAddBudgetDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_budget_category, null)
        val etName = dialogView.findViewById<EditText>(R.id.etCategoryName)
        val etAmount = dialogView.findViewById<EditText>(R.id.etBudgetAmount)

        AlertDialog.Builder(this)
            .setTitle("Add Budget Category")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val name = etName.text.toString()
                val amount = etAmount.text.toString().toDoubleOrNull()

                if (name.isNotEmpty() && amount != null && amount > 0) {
                    val newId = budgetCategories.size + 1
                    val newCategory = BudgetCategory(newId, name, amount, 0.0, R.color.food_bg)
                    budgetCategories.add(newCategory)
                    budgetAdapter.updateData(budgetCategories)
                    updateBudgetSummary()
                    Toast.makeText(this, "Budget category added", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Please enter valid name and amount", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditBudgetDialog(category: BudgetCategory) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_budget_category, null)
        val etName = dialogView.findViewById<EditText>(R.id.etCategoryName)
        val etAmount = dialogView.findViewById<EditText>(R.id.etBudgetAmount)

        etName.setText(category.name)
        etAmount.setText(category.budgetAmount.toString())

        AlertDialog.Builder(this)
            .setTitle("Edit Budget Category")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text.toString()
                val amount = etAmount.text.toString().toDoubleOrNull()

                if (name.isNotEmpty() && amount != null && amount > 0) {
                    val index = budgetCategories.indexOfFirst { it.id == category.id }
                    if (index >= 0) {
                        budgetCategories[index] = category.copy(name = name, budgetAmount = amount)
                        budgetAdapter.updateData(budgetCategories)
                        updateBudgetSummary()
                        Toast.makeText(this, "Budget updated", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Delete") { _, _ ->
                budgetCategories.removeAll { it.id == category.id }
                budgetAdapter.updateData(budgetCategories)
                updateBudgetSummary()
                Toast.makeText(this, "Category deleted", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Cancel", null)
            .show()
    }

    private fun showEditTotalBudgetDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_total_budget, null)
        val etTotalBudget = dialogView.findViewById<EditText>(R.id.etTotalBudget)
        etTotalBudget.setText(totalBudget.toString())

        AlertDialog.Builder(this)
            .setTitle("Edit Total Budget")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val newTotal = etTotalBudget.text.toString().toDoubleOrNull()
                if (newTotal != null && newTotal > 0) {
                    totalBudget = newTotal
                    updateBudgetSummary()
                    Toast.makeText(this, "Total budget updated", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // Adapter for budget categories
    inner class BudgetCategoryAdapter(
        private var categories: List<BudgetCategory>,
        private val onItemClick: (BudgetCategory) -> Unit
    ) : RecyclerView.Adapter<BudgetCategoryAdapter.ViewHolder>() {

        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val tvName: TextView = itemView.findViewById(R.id.tvCategoryName)
            val tvBudget: TextView = itemView.findViewById(R.id.tvBudgetAmount)
            val tvSpent: TextView = itemView.findViewById(R.id.tvSpentAmount)
            val tvRemaining: TextView = itemView.findViewById(R.id.tvRemainingAmount)
            val progressBar: ProgressBar = itemView.findViewById(R.id.progressCategoryBudget)
            val viewColor: View = itemView.findViewById(R.id.viewColorIndicator)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = layoutInflater.inflate(R.layout.item_budget_category, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val category = categories[position]
            val remaining = category.budgetAmount - category.spentAmount
            val percentage = ((category.spentAmount / category.budgetAmount) * 100).toInt()

            holder.tvName.text = category.name
            holder.tvBudget.text = String.format("Budget: $%.2f", category.budgetAmount)
            holder.tvSpent.text = String.format("Spent: $%.2f", category.spentAmount)
            holder.tvRemaining.text = if (remaining >= 0)
                String.format("Remaining: $%.2f", remaining)
            else
                String.format("Over: $%.2f", -remaining)

            holder.tvRemaining.setTextColor(
                if (remaining >= 0)
                    ContextCompat.getColor(this@BudgetActivity, R.color.grocery_text)
                else
                    ContextCompat.getColor(this@BudgetActivity, R.color.delete_text)
            )

            holder.progressBar.progress = minOf(percentage, 100)
            holder.viewColor.setBackgroundColor(
                ContextCompat.getColor(this@BudgetActivity, category.color)
            )

            holder.itemView.setOnClickListener { onItemClick(category) }
        }

        override fun getItemCount(): Int = categories.size

        fun updateData(newCategories: List<BudgetCategory>) {
            categories = newCategories
            notifyDataSetChanged()
        }
    }
}