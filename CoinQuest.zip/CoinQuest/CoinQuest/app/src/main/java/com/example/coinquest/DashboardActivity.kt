package com.example.coinquest

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.coinquest.databinding.ActivityDashboardBinding

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPreferences = getSharedPreferences("coinquest_prefs", Context.MODE_PRIVATE)
        val userEmail = sharedPreferences.getString("user_email", "User")
        val userName = sharedPreferences.getString("user_name", "User")

        binding.tvUserName.text = "Welcome, $userName!"
        binding.tvUserEmail.text = userEmail

        binding.btnLogout.setOnClickListener {
            // Clear session
            sharedPreferences.edit().clear().apply()

            Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show()

            // Go back to login
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}