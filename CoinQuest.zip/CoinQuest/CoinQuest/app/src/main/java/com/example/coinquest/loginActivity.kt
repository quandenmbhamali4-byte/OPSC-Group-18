package com.example.coinquest

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.test.isEnabled
import com.example.coinquest.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize View Binding
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Check if user is already logged in
        val sharedPreferences = getSharedPreferences("coinquest_prefs", Context.MODE_PRIVATE)
        val isLoggedIn = sharedPreferences.getBoolean("is_logged_in", false)

        if (isLoggedIn) {
            // User already logged in, go to dashboard
            startActivity(Intent(this, DashboardActivity::class.java))
            finish()
            return
        }

        // Set up click listeners
        setupListeners()
    }

    private fun setupListeners() {
        binding.btnLogin.setOnClickListener {
            val email = binding.userEmail.text.toString().trim()
            val password = binding.Password.text.toString().trim()

            if (validateInput(email, password)) {
                performLogin(email, password)
            }
        }

        binding.btnRegister.setOnClickListener {
            val email = binding.userEmail.text.toString().trim()
            val password = binding.Password.text.toString().trim()

            if (validateInput(email, password)) {
                performRegistration(email, password)
            }
        }

        binding.btnGoogleSignIn.setOnClickListener {
            Toast.makeText(this, "Google Sign-In coming soon!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun validateInput(email: String, password: String): Boolean {
        return when {
            email.isEmpty() -> {
                binding.userEmail.error = "Email is required"
                false
            }
            !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                binding.userEmail.error = "Enter a valid email address"
                false
            }
            password.isEmpty() -> {
                binding.Password.error = "Password is required"
                false
            }
            password.length < 4 -> {
                binding.Password.error = "Password must be at least 4 characters"
                false
            }
            else -> true
        }
    }

    private fun performLogin(email: String, password: String) {
        // Show loading
        showLoading(true)

        // Simulate network request
        Handler(Looper.getMainLooper()).postDelayed({
            // Save user session
            val sharedPreferences = getSharedPreferences("coinquest_prefs", Context.MODE_PRIVATE)
            sharedPreferences.edit().apply {
                putBoolean("is_logged_in", true)
                putString("user_email", email)
                putString("user_name", email.substringBefore("@"))
                apply()
            }

            showLoading(false)
            Toast.makeText(this, "Welcome ${email.substringBefore("@")}!", Toast.LENGTH_LONG).show()

            // Navigate to dashboard
            startActivity(Intent(this, DashboardActivity::class.java))
            finish()

        }, 1500)
    }

    private fun performRegistration(email: String, password: String) {
        showLoading(true)

        Handler(Looper.getMainLooper()).postDelayed({
            showLoading(false)
            Toast.makeText(this, "Registration successful! Please login.", Toast.LENGTH_LONG).show()
            binding.Password.text?.clear()
        }, 1500)
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = android.view.View.VISIBLE
            binding.btnLogin.isEnabled = false
            binding.btnRegister.isEnabled = false
            binding.btnGoogleSignIn.isEnabled = false
        } else {
            binding.progressBar.visibility = android.view.View.GONE
            binding.btnLogin.isEnabled = true
            binding.btnRegister.isEnabled = true
            binding.btnGoogleSignIn.isEnabled = true
        }
    }
}