# 💰 CoinQuest – Personal Budget Tracker App

## 📱 Overview
CoinQuest is a modern Android budgeting application designed to help users manage their finances in a simple, engaging, and gamified way.

## 🚀 Features
- User authentication (login/register)
- Expense tracking (add/edit/delete)
- Budget management
- Budget Beast (gamification)
- Profile screen
- Splash screen

## 🏗️ Tech Stack
- Kotlin
- MVVM Architecture
- Room Database
- Material Design

## 📂 Project Structure
com.coinquest/
 ├── data
 ├── viewmodel
 ├── ui
 ├── utils
 └── MainActivity.kt

## ⚙️ Setup
1. Clone repo
2. Open in Android Studio
3. Run app

## 🎥 Demo
(Add your video link)

## 👨‍💻 Author
Your Name
